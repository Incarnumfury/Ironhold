using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class RotateCamera : MonoBehaviour
{
    [SerializeField]
    GameObject followTarget;
    private float aimValue;
    private Vector2 _look;
    private Quaternion nextRotation;
    private float rotationLerp = 0.5f;

    private Vector3 prevpos;
    private float lookangle;

    public void OnLook(InputValue value)
    {
        _look = value.Get<Vector2>();
    }
    
    public void OnAim(InputValue value)
    {
        aimValue = value.Get<float>();
    }
        [SerializeField]
    private float rotationPower = 1f;


    void Start() {
        prevpos = transform.position;
    }
    // Start is called before the first frame update

    // Update is called once per frame
    void Update()
    {
            
            
            followTarget.transform.rotation *= Quaternion.AngleAxis(_look.x * rotationPower, Vector3.up);
            followTarget.transform.rotation *= Quaternion.AngleAxis(-_look.y * rotationPower, Vector3.right);

            var angles = followTarget.transform.localEulerAngles;
            angles.z = 0;
            var angle = followTarget.transform.localEulerAngles.x;

            if (angle > 180 && angle < 340)
            {
                angles.x = 340;
            }
            else if(angle < 180 && angle > 40)
            {
                angles.x = 40;
            }
            if(aimValue == 1)
            {
                //Set the player rotation based on the look transform
                 transform.rotation = Quaternion.Euler(0, followTarget.transform.rotation.eulerAngles.y, 0);
                //reset the y rotation of the look transform
                followTarget.transform.localEulerAngles = new Vector3(angles.x, 0, 0);

                
                return;
            }

            followTarget.transform.localEulerAngles = angles;
            nextRotation = Quaternion.Lerp(followTarget.transform.rotation, nextRotation, Time.deltaTime * rotationLerp);
            followTarget.transform.rotation *= Quaternion.AngleAxis(_look.x * rotationPower, Vector3.up);


    }
}
