using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class AimCamera : MonoBehaviour
{
    private float aimValue;
        public void OnAim(InputValue value)
    {
        aimValue = value.Get<float>();
    }
    
    [SerializeField]
    GameObject camera1,camera2,playerfollow,player;

    private character_movement charmov;
    private void Start()
    {
        charmov = player.GetComponent<character_movement>();
    }
    void Update()
    {
        if(aimValue == 1 && !camera2.activeInHierarchy)
        {
            playerfollow.transform.SetParent(player.transform);
            playerfollow.transform.localEulerAngles = new Vector3(0,transform.rotation.y,0);
            camera1.SetActive(false);
            camera2.SetActive(true);
        }else if(aimValue != 1 && !camera1.activeInHierarchy)
        {
             playerfollow.transform.SetParent(null);
            camera1.SetActive(true);
            camera2.SetActive(false);
        }
    }
}
