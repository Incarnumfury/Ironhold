using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;
public class CombatManager : MonoBehaviour
{
    public static CombatManager Instance { get; private set; }
    public bool canReciveInput;
    public bool inputRecived;
    public bool isFighting;
    public bool candealDamage;
    public AudioSource soundSource;
    public AudioClip[] sounds;
    public SwordScript onSwordEnterEvent;
    public List<Collider> cols;
    private string currentanim;
    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            Instance = this;
            onSwordEnterEvent.onTriggerEnter.AddListener(EnemyHit);

        }
        DontDestroyOnLoad(this.gameObject);
    }

    public void OnFire(InputValue value)
    {
        if (!gameObject.GetComponent<character_movement>().isrolling)
        {
            if (canReciveInput)
            {
                inputRecived = true;
                canReciveInput = false;
            }
        }

    }
    private void EnemyHit(Collider col)
    {

        if (col.gameObject.tag == "Enemy" && candealDamage && !cols.Contains(col) && col.isTrigger)
        {
            Debug.Log("Hit");
            if(col.gameObject.GetComponent<MeleeEnemy>() != null)
            {
                col.gameObject.GetComponent<MeleeEnemy>().health.RemoveHealth(50);
            }
            if (col.gameObject.GetComponent<RangeEnemy>() != null)
            {
                col.gameObject.GetComponent<RangeEnemy>().health.RemoveHealth(50);
            }
            cols.Add(col);
        }
        else if (cols.Contains(col))
        {
            Debug.Log("alreadyhit");
        }
    }
    public void Inputmanger()
    {
        if (!canReciveInput)
        {
            canReciveInput = true;
        }
        else
        {
            canReciveInput = false;
        }
    }
}
