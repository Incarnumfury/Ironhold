using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class EnemyMeleeSword : MonoBehaviour
{
    public UnityEvent<Collider> onTriggerEnter;
    public GameObject guy;
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player" && guy.GetComponent<MeleeEnemy>().attacking)
        {
            if (guy.gameObject.GetComponent<MeleeEnemy>() != null)
            {
                if (onTriggerEnter != null) onTriggerEnter.Invoke(other);
            }
        }
    }
}
