README - IRONHOLD Code Explanation

DESCRIPTION:
This code goes into making a 3rd-person action game called IRONHOLD. IRONHOLD is a game where you the player are tasked with ridding the plague of rust from the Dwarven fortress and to slay what lies beneath. With this being written using Visual Studio we are utilizing the Unity Plugin to use their third party code development to utilize the functions they have created to use their game engine.

BUILD INSTRUCTIONS:
Because of the Unity engine and the complexity and interconnectedness of game development building the individual code is impossible and will result in errors. This is due to the interdependency of the .cs files and the various Unity Libraries. In order to test the build in its entirety you must run the build in the Unity game engine. We will include the Unity project file in our final report so that you may test the build.

CODE ORGANIZATION:
The organization of the code is in an unorthodox manner due to the object dependency of the code. The scripts are written to interact with specific Unity objects, therefor, all scripts are organized into the areas with the objects that they will be interacting with for ease of development purposes.

3RD PARTY LIBRARY:
With our code we used the Unity plugin that allowed us to use the functions that they have made to interact with the Unity engine. This saved us valuable development time as we did not have to create high-level and complicated functions to allow us to develop the game. All tools we used belong to the Microsoft Corporation and are free use, https://docs.microsoft.com/en-us/visualstudio/gamedev/unity/get-started/visual-studio-tools-for-unity.