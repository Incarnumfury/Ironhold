using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class RangeEnemy : MonoBehaviour
{
    public HealthScript health = new HealthScript(250);
    public GameObject Player;
    private NavMeshAgent agent;
    float currenthealth;
    private Animator anim;
    private Vector3 lastPostion;
    private float attackspeed = 4f;
    private float timetooattack;
    private float stuntimer;
    private float stuntime = 4;
    private bool hasseenplayer = false;
    public bool charging;
    private bool playclip;
    public AudioClip[] audioclips;
    public AudioSource source;
    public BoxCollider collider;
    public List<Collider> cols;
    public bool attacking;

    public GameObject bullet;
    public GameObject gun;
    private int viewdistance = 25;
    // Start is called before the first frame update
    private void Start()
    {
        Player = GameObject.FindGameObjectWithTag("Player");
        currenthealth = health.GetHealth();
        anim = gameObject.GetComponent<Animator>();
        lastPostion = transform.position;
        agent = gameObject.GetComponent<NavMeshAgent>();
        source = gameObject.GetComponent<AudioSource>();

    }

    public void shoot()
    {
        GameObject firedbullet = Instantiate(bullet, gun.transform.position,Quaternion.identity);
    }
    // Update is called once per frame
    void Update()
    {
        if (!anim.GetBool("isDead") || Player.GetComponent<playerhealth>().health.GetHealth() > 0)
        {
            timetooattack -= Time.deltaTime;
            stuntimer -= Time.deltaTime;
            if (Vector3.Distance(transform.position, Player.transform.position) < viewdistance)
            {
                if (!hasseenplayer)
                {
                    source.Stop();
                    hasseenplayer = true;
                    viewdistance = 40;
                }
                else if (hasseenplayer)
                {       
                    if (Vector3.Distance(transform.position, Player.transform.position) <= 30)
                    {
                        anim.SetBool("Walking", false);
                        agent.SetDestination(transform.position);
                        Vector3 lookatpos = new Vector3(Player.transform.position.x, transform.position.y, Player.transform.position.z);
                        transform.LookAt(lookatpos);
                        if (timetooattack <= 0)
                        {
                            source.loop = false;
                            timetooattack = attackspeed;
                        }
                    }
                    else if(!attacking)
                    {
                        anim.SetBool("Walking", true);
                        agent.SetDestination(Player.transform.position);
                        source.clip = audioclips[0];
                        if (!playclip)
                        {
                            source.Play();
                            playclip = true;
                            source.loop = true;
                        }
                    }
                    if(Vector3.Distance(transform.position, Player.transform.position) <= 21 && !anim.GetBool("Walking"))
                    {
                        anim.SetTrigger("Shooting");

                    }
                }
            }
            else
            {
                anim.SetBool("Walking", false);
                agent.SetDestination(transform.position);
                source.Stop();
                playclip = false;
                source.loop = false;
            }

            float velocity = (transform.position - lastPostion).magnitude;
            if (velocity > .001)
            {

                anim.SetBool("Walking", true);
            }
            else
            {
                anim.SetBool("Walking", false);

            }
            if (currenthealth != health.GetHealth())
            {
                if (!health.getDead())
                {
                    currenthealth = health.GetHealth();
                    if (stuntimer < 0)
                    {
                        anim.SetTrigger("hit");
                    }
                    stuntimer = stuntime;
                    source.Play();

                }

            }
            if (health.getDead())
            {
                anim.SetBool("isDead", true);
                collider.enabled = false;
                this.enabled = false;
            }
            lastPostion = transform.position;
        }
        else
        {
            agent.SetDestination(transform.position);

        }
    }
    private void OnTriggerEnter(Collider other)
    {

    }
}
