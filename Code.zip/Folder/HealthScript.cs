﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthScript
{
    private float maxHealth;
    private float health;
    private bool isDead;
    public HealthScript(float maxHealth)
    {
        this.maxHealth = maxHealth;
        this.health = maxHealth;
    }

    public float GetHealth()
    {
        return health;
    }
    public float GetMaxHealth()
    {
        return maxHealth;
    }
    public void IncreaseMaxHealth(float addhealth)
    {
        maxHealth += addhealth;
    }
    public void Addhealth(float addhealth)
    {
        health += addhealth;
        isDead = false;
        if (health > maxHealth)
        {
            health = maxHealth;
        }
    }
    public void SetHealth(float setHealth)
    {
        if (setHealth < 0)
        {
            setHealth = 0;
        }
        health = setHealth;

        if (health > maxHealth)
        {
            health = maxHealth;
        }

        if (setHealth != 0)
        {
            isDead = false;
        }
        else
        {
            isDead = true;

        }
    }
    public void RemoveHealth(float removeHealth)
    {
        health -= removeHealth;
        if (health <= 0)
        {
            isDead = true;
        }
    }
    public bool getDead()
    {
        if(GetHealth() <= 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}
