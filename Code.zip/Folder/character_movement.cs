using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
public class character_movement : MonoBehaviour
{
    private Vector2 _move;
    [SerializeField]
    private float rotateSpeed;
    private float aimValue;
    private Vector3 direction;
    [SerializeField]
    private float walkspeed,runspeedmult,blockwalk,rollspeed;
    private float gravityValue = -9.81f;
    public CharacterController controller;
    private BoxCollider collider;
    [SerializeField]
    private Animator animator;
    private bool isaim = false;
    public bool isrun = false;
    public bool ismoving;
    public bool isrolling;
    private float rolltime = 1;
    private float rolltiimer;
    private float aimfloat;
    private float runfloat;
    public bool getUp;
    public bool fallendown;
    public bool hit;
    private bool playhit = false;
    private bool playheal = false;

    public AudioSource hitsource;

    public bool heal = false;
    // Start is called before the first frame update
    void Start()
    {
        controller = gameObject.GetComponent<CharacterController>();
        collider = gameObject.GetComponent<BoxCollider>();

    }
    public void OnAbility(InputValue value)
    {
        if (!heal)
        {
            heal = true;
        }
    }
    public void OnMove(InputValue value)
    {
        _move = value.Get<Vector2>();


    }
    public void OnRun(InputValue value)
    {
        runfloat = value.Get<float>();
        if (!isrolling)
        {
            if (runfloat > 0)
            {
                animator.SetBool("Running", true);
                isrun = true;

            }
            else
            {
                animator.SetBool("Running", false);
                isrun = false;
            }
        }

    }

    public void OnRoll(InputValue value)
    {
        if(!isrolling){
            isrolling = true;
            rolltiimer = rolltime;
            animator.SetBool("Running", false);

            direction = new Vector3(_move.x, 0, _move.y);
            direction = Camera.main.gameObject.transform.TransformDirection(direction);
            direction *= Time.deltaTime * rollspeed;
            if(_move.magnitude == 0)
            {
                animator.SetTrigger("Roll");
            }
            else
            {
                Quaternion roation = Quaternion.LookRotation(direction);
                transform.rotation = Quaternion.RotateTowards(transform.rotation, new Quaternion(0, roation.y, 0, roation.w), 1000000 * Time.deltaTime);
                animator.SetTrigger("Roll");
            }


        }
    }
    public void OnAim(InputValue value){
        aimfloat = value.Get<float>();

            if (aimfloat != 0)
            {
                isaim = true;
            }
            else
            {
                isaim = false;
            }

        animator.SetBool("Shield", isaim);
        direction = new Vector3(_move.x,0,_move.y);
        direction = Camera.main.gameObject.transform.TransformDirection(direction);
        direction *=Time.deltaTime * blockwalk;
        aimValue = value.Get<float>();


    }
    // Update is called once per frame
    void Update()
    {
        if (runfloat == 0)
        {
            animator.SetBool("Running", false);
            isrun = false;
        }
        if (_move.magnitude != 0)
        {
            ismoving = true;
        }
        if (!isaim)
        {
            animator.SetBool("Shield", false);
            isaim = false;
        }
        else
        {
            ismoving = false;
            animator.SetBool("WalkingLeft", false);
            animator.SetBool("WalkingRight", false);
            animator.SetBool("Walking", false);
        }
        if (hit && !playhit)
        {
            animator.SetTrigger("Hit");
            hitsource.Play();
            playhit = true;
        }
        if(!hit && playhit)
        {
            playhit = false;

        }
        if (!CombatManager.Instance.isFighting && !isrolling && !fallendown && !hit && !animator.GetBool("Death"))
        {

            direction = new Vector3(_move.x, 0, _move.y);
            direction = Camera.main.gameObject.transform.TransformDirection(direction);
            direction *= Time.deltaTime * walkspeed;
            if (_move.x < 0)
            {
                animator.SetBool("WalkingLeft", true);
                animator.SetBool("WalkingRight", false);
                animator.SetBool("Walking", true);

            }
            if (_move.x == 0)
            {
                animator.SetBool("WalkingLeft", false);
                animator.SetBool("WalkingRight", false);
            }
            else if (_move.x > 0)
            {
                animator.SetBool("WalkingRight", true);
                animator.SetBool("WalkingLeft", false);
                animator.SetBool("Walking", true);
            }
            if (_move.y > 0)
            {
                animator.SetBool("Walking", true);
                animator.SetBool("WalkingBack", false);

            }
            if (_move.y < 0)
            {
                animator.SetBool("Walking", true);
                animator.SetBool("WalkingBack", true);
            }
            if (direction.magnitude == 0)
            {
                animator.SetBool("WalkingRight", false);
                animator.SetBool("WalkingLeft", false);
                animator.SetBool("Walking", false);
                animator.SetBool("WalkingBack", false);

                if (heal && !playheal)
                {
                    playheal = true;
                    animator.SetTrigger("Heal");
                }
                if (!heal && playheal)
                {
                    playheal = false;
                }

            }
            direction.y = gravityValue * Time.deltaTime;
            if ((animator.GetBool("WalkingRight") || animator.GetBool("WalkingLeft")) && animator.GetBool("Shield"))
            {
                controller.Move(direction / 2.5f);

            }
            else
            {
                if (isrun && !isaim)
                {
                    controller.Move(direction * runspeedmult);
                }
                else if(isrun && isaim)
                {
                    controller.Move(direction );

                }
                else
                {
                    controller.Move(direction);
                }
            }
            if (aimValue != 1 && _move.magnitude != 0)
            {
                Quaternion roation = Quaternion.LookRotation(direction);
                transform.rotation = Quaternion.RotateTowards(transform.rotation, new Quaternion(0, roation.y, 0, roation.w), rotateSpeed * Time.deltaTime);
            }
        }
        if (fallendown)
        {
            if (collider.enabled)
            {
                animator.SetTrigger("Fall");
            }
            collider.enabled = false;
            controller.enabled = false;
        }
        if(fallendown && getUp)
        {
            fallendown = false;
            getUp = false;
            collider.enabled = true;
            controller.enabled = true;
        }
        if (isrolling)
        {
            controller.Move(transform.rotation * Vector3.forward * 12 * Time.deltaTime);
            rolltiimer -= Time.deltaTime;
            if(rolltiimer <= 0)
            {
                isrolling = false;
                if(runfloat != 0)
                {
                    animator.SetBool("Running", true);
                    isrun = true;
                }
            }
        }

    }
}