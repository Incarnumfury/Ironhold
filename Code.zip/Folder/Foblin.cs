﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Foblin : MonoBehaviour
{
    /*
    public HealthScript health = new HealthScript(150);
    private GameObject SwordRange;
    private GameObject Player;
    private NavMeshAgent agent;
    float currenthealth;
    float timer = .1f;
    private Animator anim;
    private Vector3 lastPostion;
    private float attackspeed = 1.4f;
    private float timetooattack;
    private EnemyRange range;
    private bool playerEnteredRange;
    GameObject particle;


 
    // Start is called before the first frame update
    private void Start()
    {
        Player = GameObject.FindGameObjectWithTag("Player");
        SwordRange = GameObject.Find("SwordRange");
        agent = gameObject.GetComponent<NavMeshAgent>();
        currenthealth = health.GetHealth();
        anim = gameObject.GetComponent<Animator>();
        lastPostion = transform.position;
        range = gameObject.transform.GetChild(2).GetComponent<EnemyRange>();
        playerEnteredRange = false;
    }

    // Update is called once per frame
    void Update()
    {
        timetooattack -= Time.deltaTime;
        if (Vector3.Distance(transform.position, Player.transform.position) < 30)
        {
            anim.SetBool("isWalking", true);
            agent.SetDestination(Player.transform.position);
        }
        else
        {
            anim.SetBool("isWalking", false);
            agent.SetDestination(transform.position);
        }

        float velocity = (transform.position - lastPostion).magnitude;
        if (velocity > .001)
        {
            anim.SetBool("isWalking", true);
        }
        else
        {
            anim.SetBool("isWalking", false);

        }
        if (currenthealth != health.GetHealth())
        {
            if (!health.getDead())
            currenthealth = health.GetHealth();
        }
        if (health.getDead())
        {
            timer -= Time.deltaTime;
            if (SwordRange.GetComponent<SwordCollider>().enemys.Contains(gameObject))
            {
                SwordRange.GetComponent<SwordCollider>().enemys.Remove(gameObject);
            }

            if (timer < 0)
                Destroy(gameObject);
        }

        if(playerEnteredRange == false && range.players.Count > 0)
        {
            playerEnteredRange = true;
            timetooattack = attackspeed/2;
            Debug.Log("EnterRange");
        }
        else if (playerEnteredRange == true && range.players.Count == 0)
        {
            playerEnteredRange = false;
        }

        if (range.players.Count > 0)
        {
            agent.SetDestination(transform.position);

            if (timetooattack <= 0)
            {
                anim.SetBool("isAttacking", true);

                Debug.Log("DIE");
                range.players[0].GetComponent<playerhealth>().health.RemoveHealth(45);
                timetooattack = attackspeed;
            }
        }
        else
        {
            anim.SetBool("isAttacking", false);

        }
        lastPostion = transform.position;
    }
    */
}
