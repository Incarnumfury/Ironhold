﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class playerhealth : MonoBehaviour
{

    public HealthScript health;
    public Animator anim;
    public void Start()
    {
        health = new HealthScript(PlayerStats.Instance.playerhealth);
    }
    private void Update()
    {
        Debug.Log(health.GetHealth());
        if (health.getDead())
        {
            anim.SetBool("Death", true);
        }

    }
}
