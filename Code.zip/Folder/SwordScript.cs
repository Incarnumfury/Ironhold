using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class SwordScript : MonoBehaviour
{
    public UnityEvent<Collider> onTriggerEnter;

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Enemy" && CombatManager.Instance.isFighting)
        {
            if (other.gameObject.GetComponent<MeleeEnemy>()!= null)
            {
                if (onTriggerEnter != null) onTriggerEnter.Invoke(other);
            }
            if (other.gameObject.GetComponent<RangeEnemy>() != null)
            {
                if (onTriggerEnter != null) onTriggerEnter.Invoke(other);
            }
        }
    }
}
