using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    GameObject Player;
    // Start is called before the first frame update
    void Start()
    {
        Player = GameObject.FindGameObjectWithTag("Player");
        Vector3 dir = Player.transform.position - transform.position;
        dir.Normalize();
        Vector3 newPos = dir + transform.position;

        gameObject.transform.LookAt(newPos);
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.forward * Time.deltaTime * 35);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("Hit");
            if (other.gameObject.GetComponent<playerhealth>() != null && other.isTrigger && !other.gameObject.GetComponent<character_movement>().isrolling)
            {
                other.gameObject.GetComponent<playerhealth>().health.RemoveHealth(25);
            }
            if (other.gameObject.GetComponent<character_movement>() != null && other.isTrigger && !other.gameObject.GetComponent<character_movement>().isrolling)
            {
                other.gameObject.GetComponent<character_movement>().hit = true;
            }
            Destroy(gameObject);
        }
    }
}
